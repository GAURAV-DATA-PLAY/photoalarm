package com.example.photoalarm

import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.camera.view.PreviewView

class CaptureActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val id = intent.getIntExtra("id", 0)
        val test = intent.getBooleanExtra("test", false)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(16)) }
        val info = TextView(this).apply { textSize = 18f
            text = if (test) "🧪 जांच: उसी जगह की फोटो खींचें और स्कोर देखें" else "📷 रेफरेंस फोटो: उस जगह की फोटो खींचें जहाँ सुबह जाना है" }
        val pv = PreviewView(this)
        val msg = TextView(this).apply { textSize = 16f; gravity = android.view.Gravity.CENTER }
        root.addView(info); root.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(msg)
        val cam = Cam(this, pv) { msg.text = "कैमरे की अनुमति दें" }
        root.addView(Button(this).apply { text = "📸 फोटो खींचें"; setOnClickListener {
            cam.shoot { bmp ->
                if (bmp == null) { msg.text = "❌ फोटो नहीं खिंची"; return@shoot }
                val list = Store.load(this@CaptureActivity)
                val t = list.firstOrNull { it.id == id } ?: return@shoot
                if (test) {
                    val refs = Store.refs(this@CaptureActivity, t)
                    if (refs.isEmpty()) { msg.text = "पहले रेफरेंस फोटो जोड़ें"; return@shoot }
                    val s = Match.score(bmp, refs); val th = Alarm.prefs(this@CaptureActivity).getInt("th", 55) / 100.0
                    msg.text = "स्कोर %.2f (चाहिए %.2f) → ".format(s, th) + if (s >= th) "✅ मैच" else "❌ मैच नहीं"
                } else { Store.addRef(this@CaptureActivity, list, t, bmp); finish() }
            } } })
        setContentView(root)
        cam.start()
    }
}
