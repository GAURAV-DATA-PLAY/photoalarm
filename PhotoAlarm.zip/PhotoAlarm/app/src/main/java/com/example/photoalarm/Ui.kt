package com.example.photoalarm

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*

object C {
    val BG = Color.parseColor("#F6F5F1"); val ACC = Color.parseColor("#D9480F")
    val INK = Color.parseColor("#1C1B19"); val MUT = Color.parseColor("#6B675F")
}

fun Context.shape(color: Int, r: Int = 16, stroke: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
}

fun Context.lp(top: Int = 8) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, 0) }

fun Context.card(bg: Int = Color.WHITE) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; background = shape(bg); setPadding(dp(16), dp(14), dp(16), dp(14))
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }
}

fun Context.label(t: String, size: Float = 14f, color: Int = C.INK, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.pbtn(t: String, f: () -> Unit) = Button(this).apply {
    text = t; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE); background = shape(C.ACC, 12); setOnClickListener { f() }
}

fun Context.sbtn(t: String, small: Boolean = false, f: () -> Unit) = Button(this).apply {
    text = t; isAllCaps = false; textSize = if (small) 13f else 15f; setTextColor(C.ACC)
    background = shape(Color.TRANSPARENT, 12, C.ACC); setOnClickListener { f() }
}
