package com.example.photoalarm

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = Alarm.prefs(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        val tp = TimePicker(this).apply { setIs24HourView(true); hour = p.getInt("h", 4); minute = p.getInt("m", 0) }
        val st = TextView(this).apply { textSize = 16f }
        fun refresh() { st.text = (if (p.getBoolean("on", false)) "अलार्म चालू ✅ ${"%02d:%02d".format(p.getInt("h", 4), p.getInt("m", 0))}" else "अलार्म बंद") + "\nस्ट्रीक: ${p.getInt("streak", 0)} दिन" }
        root.addView(TextView(this).apply { text = "⏰ फोटो अलार्म"; textSize = 24f })
        root.addView(tp)
        root.addView(Button(this).apply { text = "अलार्म चालू करें"; setOnClickListener {
            p.edit().putInt("h", tp.hour).putInt("m", tp.minute).apply(); Alarm.schedule(this@MainActivity); refresh() } })
        root.addView(Button(this).apply { text = "अभी टेस्ट करें"; setOnClickListener { startForegroundService(Intent(this@MainActivity, AlarmService::class.java)) } })
        root.addView(Button(this).apply { text = "अलार्म बंद करें"; setOnClickListener { p.edit().putBoolean("on", false).apply()
            (getSystemService(ALARM_SERVICE) as android.app.AlarmManager).cancel(android.app.PendingIntent.getBroadcast(this@MainActivity, 1, Intent(this@MainActivity, AlarmReceiver::class.java), android.app.PendingIntent.FLAG_NO_CREATE or android.app.PendingIntent.FLAG_IMMUTABLE) ?: return@setOnClickListener); refresh() } })
        root.addView(st); refresh(); setContentView(ScrollView(this).apply { addView(root) })

        val need = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(need.toTypedArray(), 1)
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, android.net.Uri.parse("package:$packageName")))
    }
}
