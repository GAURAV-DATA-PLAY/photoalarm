package com.example.photoalarm

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private var targets = mutableListOf<Target>()
    private lateinit var dash: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var songTxt: TextView
    private lateinit var diag: TextView
    private var asking = false
    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) setSong(uri) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = Alarm.prefs(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(20), dp(16), dp(28)); setBackgroundColor(C.BG) }

        val head = card(C.ACC)
        head.addView(label("⏰ जागो", 28f, Color.WHITE, true))
        head.addView(label("हर लक्ष्य का अपना समय, अपनी फोटो", 14f, Color.parseColor("#FFE3D3")))
        root.addView(head)

        val crashF = File(filesDir, "crash.txt")
        if (crashF.exists()) {
            val cc = card(Color.parseColor("#FDE8E8"))
            cc.addView(label("⚠️ पिछली बार ऐप क्रैश हुआ। नीचे लिखे का स्क्रीनशॉट भेजें:", 14f, C.INK, true))
            cc.addView(TextView(this).apply { text = crashF.readText(); textSize = 10f; setTextColor(Color.BLACK); setTextIsSelectable(true) }, lp(6))
            cc.addView(sbtn("ठीक है, हटाएं") { crashF.delete(); cc.visibility = android.view.View.GONE }, lp(6))
            root.addView(cc)
        }

        dash = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(dash)

        root.addView(label("🎯 मेरे लक्ष्य", 20f, C.INK, true), lp(8))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, lp(8))
        root.addView(pbtn("➕  नया लक्ष्य जोड़ें") {
            if (targets.size >= 20) return@pbtn
            targets.add(Target(Store.nextId(targets), "", 0, true, 6, 0)); Store.save(this, targets); refresh() }, lp(4))

        // ---- सेटिंग्स
        root.addView(label("⚙️ सेटिंग्स", 20f, C.INK, true), lp(24))
        val sc = card()
        sc.addView(label("🎵 अलार्म की आवाज़", 16f, C.INK, true))
        songTxt = label("", 13f, C.MUT); sc.addView(songTxt, lp(2))
        val sr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sr.addView(sbtn("🎶 गाना चुनें", true) { pick.launch(arrayOf("audio/*")) }, LinearLayout.LayoutParams(0, -2, 1f))
        sr.addView(sbtn("↩ डिफ़ॉल्ट", true) { File(filesDir, "ringtone").delete(); p.edit().remove("song").apply(); songLabel() }, LinearLayout.LayoutParams(0, -2, 1f))
        sc.addView(sr, lp(6)); root.addView(sc); songLabel()

        val hc = card()
        val thTxt = label("", 13f, C.MUT)
        fun thLabel() { thTxt.text = "मैच की सख्ती: ${p.getInt("th", 55)}%  (ज़्यादा = कठिन)" }
        thLabel(); hc.addView(label("🎚 फोटो मैच कितना सटीक चाहिए", 16f, C.INK, true)); hc.addView(thTxt, lp(2))
        hc.addView(SeekBar(this).apply { max = 60; progress = p.getInt("th", 55) - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { p.edit().putInt("th", 30 + v).apply(); thLabel() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} }) }, lp(6))
        root.addView(hc)

        val tc = card()
        tc.addView(label("🔧 जाँच और अनुमतियाँ", 16f, C.INK, true))
        tc.addView(sbtn("🔔 अलार्म टेस्ट करें", true) { ringTest() }, lp(6))
        tc.addView(sbtn("🔐 अनुमतियाँ जाँचें", true) { if (!askPermissions(true)) toast("✅ सारी ज़रूरी अनुमतियाँ मिल चुकी हैं") }, lp(4))
        diag = label("", 11f, C.MUT); tc.addView(diag, lp(6))
        root.addView(tc)

        setContentView(ScrollView(this).apply { setBackgroundColor(C.BG); addView(root) })

        val need = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(need.toTypedArray(), 1)
    }

    override fun onResume() {
        super.onResume()
        targets = Store.load(this)
        try { Alarm.scheduleAll(this) } catch (e: Throwable) {}
        refresh(); status()
        askPermissions()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    /** ज़रूरी अनुमतियाँ एक-एक करके पॉपअप से माँगता है। कुछ दिखाया तो true। */
    private fun askPermissions(force: Boolean = false): Boolean {
        if (asking || checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return false
        val p = Alarm.prefs(this)
        fun due(key: String, limit: Int) = force || p.getInt(key, 0) < limit
        fun dlg(key: String, title: String, msg: String, go: () -> Unit): Boolean {
            asking = true; p.edit().putInt(key, p.getInt(key, 0) + 1).apply()
            android.app.AlertDialog.Builder(this).setTitle(title).setMessage(msg).setCancelable(false)
                .setPositiveButton("अनुमति दें") { _, _ -> asking = false; go() }
                .setNegativeButton("बाद में") { _, _ -> asking = false }.show()
            return true
        }
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent() && due("ask_fsi", 1))
            return dlg("ask_fsi", "फुल-स्क्रीन अलार्म", "लॉक स्क्रीन पर अलार्म दिखाने के लिए अगली स्क्रीन में इसे चालू करें।") {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))) }
        if (!Settings.canDrawOverlays(this) && due("ask_ov", 1))
            return dlg("ask_ov", "दूसरे ऐप के ऊपर दिखाएं", "अलार्म बजते ही फोटो वाली स्क्रीन अपने आप खुले, इसके लिए अगली स्क्रीन में इसे चालू करें।") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && due("ask_bat", 2))
            return dlg("ask_bat", "बैटरी की छूट", "अलार्म ठीक समय पर बजे, इसके लिए ऐप को बैटरी सेविंग से छूट दें। अगली स्क्रीन पर 'Allow' दबाएं।") {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
        return false
    }

    private fun ringTest() {
        val t = targets.firstOrNull { it.refs > 0 } ?: run { toast("पहले किसी लक्ष्य में फोटो जोड़ें"); return }
        Alarm.prefs(this).edit().putBoolean("test", true).apply()
        Alarm.setRinging(this, setOf(t.id))
        startForegroundService(Intent(this, AlarmService::class.java))
    }

    private fun songLabel() { songTxt.text = "वर्तमान: " + (Alarm.prefs(this).getString("song", null) ?: "डिफ़ॉल्ट गाना") }

    private fun setSong(uri: Uri) {
        val tmp = File(filesDir, "ringtone_new")
        try {
            val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else null } ?: "मेरा गाना"
            contentResolver.openInputStream(uri)!!.use { inp -> FileOutputStream(tmp).use { inp.copyTo(it) } }
            val mp = MediaPlayer(); try { mp.setDataSource(tmp.path); mp.prepare() } finally { mp.release() }
            tmp.copyTo(File(filesDir, "ringtone"), overwrite = true); tmp.delete()
            Alarm.prefs(this).edit().putString("song", name).apply(); songLabel()
            toast("✅ गाना लग गया")
        } catch (e: Exception) { tmp.delete(); toast("❌ यह फाइल गाने के रूप में नहीं चली, कोई और चुनें") }
    }

    /** ऊपर का डैशबोर्ड: आँकड़े और अगला अलार्म। */
    private fun status() {
        val p = Alarm.prefs(this)
        dash.removeAllViews()
        val act = targets.filter { it.on && it.refs > 0 }
        val done = act.count { Alarm.isDone(this, it.id) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tile(num: String, lbl: String, last: Boolean) =
            row.addView(stat(num, lbl), LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, if (last) 0 else dp(8), 0) })
        tile("${act.size}", "सक्रिय अलार्म", false); tile("$done/${act.size}", "आज पूरे", false); tile("${p.getInt("streak", 0)}", "दिन की स्ट्रीक", true)
        dash.addView(row, lp(0))

        val nx = targets.map { it to Alarm.effectiveNext(this, it) }.filter { it.second > 0 }.minByOrNull { it.second }
        val nc = card()
        (nc.layoutParams as LinearLayout.LayoutParams).topMargin = dp(12)
        if (nx != null) {
            nc.addView(label("⏭  अगला अलार्म", 13f, C.MUT))
            nc.addView(label(nx.first.name.ifBlank { "लक्ष्य" }, 22f, C.INK, true), lp(2))
            nc.addView(label(Alarm.nextText(this, nx.first), 14f, C.ACC, true), lp(2))
        } else {
            nc.addView(label("⏭  कोई अलार्म सेट नहीं है", 15f, C.INK, true))
            nc.addView(label("नीचे लक्ष्य जोड़ें, उसकी रेफरेंस फोटो डालें और समय चुनें।", 13f, C.MUT), lp(2))
        }
        dash.addView(nc)

        diag.text = (p.getString("schedErr", null)?.let { "⚠️ अलार्म सेट नहीं हुआ: $it\n" } ?: "") +
            (p.getString("lastFire", null)?.let { "आखिरी बार अलार्म ट्रिगर हुआ: $it" } ?: "अभी तक कोई अलार्म ट्रिगर नहीं हुआ") +
            (p.getString("fireErr", null)?.let { "\n⚠️ $it" } ?: "")
    }

    private fun saveAll() { Store.save(this, targets); Alarm.scheduleAll(this); refresh(); status() }

    private fun pickMode(t: Target, i: Int) {
        val today = LocalDate.now()
        when (i) {
            0 -> { t.repeat = 1; t.date = today.toString(); Alarm.prefs(this).edit().remove("done_${t.id}").apply(); t.on = true }
            1 -> { t.repeat = 1; t.date = today.plusDays(1).toString(); t.on = true }
            else -> { t.repeat = 0; t.on = true }
        }
        if (i == 0 && Alarm.nextMillis(t) < 0 && t.refs > 0) toast("⚠️ आज का यह समय निकल चुका है। समय आगे करें, या 'कल' / 'रोज़' चुनें")
        saveAll()
    }

    private fun timeDialog(t: Target) {
        android.app.TimePickerDialog(this, { _, h, m ->
            t.hour = h; t.minute = m; Store.save(this, targets); Alarm.scheduleAll(this)
            val now = java.util.Calendar.getInstance()
            if (t.on && t.refs > 0 && !Alarm.isDone(this, t.id) && now.get(java.util.Calendar.HOUR_OF_DAY) == h && now.get(java.util.Calendar.MINUTE) == m &&
                (t.repeat == 0 || t.date == LocalDate.now().toString())) {
                Alarm.fireSoon(this, t); toast("⏰ यही समय चल रहा है, अलार्म अभी बजेगा")
            } else if (t.repeat == 1 && t.refs > 0 && Alarm.nextMillis(t) < 0 && t.date == LocalDate.now().toString()) {
                toast("⚠️ आज का यह समय निकल चुका है। समय आगे करें, या 'कल' / 'रोज़' चुनें")
            }
            refresh(); status()
        }, t.hour, t.minute, false).show()
    }

    private fun addBtn(row: LinearLayout, v: android.view.View, last: Boolean = false) =
        row.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, if (last) 0 else dp(8), 0) })

    private fun refresh() {
        list.removeAllViews()
        if (targets.isEmpty()) list.addView(label("अभी कोई लक्ष्य नहीं है। नीचे '➕ नया लक्ष्य जोड़ें' दबाकर शुरू करें।", 14f, C.MUT))
        targets.forEach { t ->
            val c = card()
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            top.addView(EditText(this).apply { hint = "लक्ष्य का नाम (जैसे: ब्रश करो)"; setText(t.name); textSize = 18f
                setTypeface(typeface, Typeface.BOLD); setTextColor(C.INK); background = null; setPadding(0, dp(6), 0, dp(6))
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { t.name = s.toString(); Store.save(this@MainActivity, targets) }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {} }) }, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(Switch(this).apply { isChecked = t.on
                setOnCheckedChangeListener { _, v -> t.on = v; saveAll() } })
            c.addView(top)

            c.addView(sbtn("⏰   ${fmtT(t.hour, t.minute)}   •   समय बदलें") { timeDialog(t) }, lp(6))
            val sel = when { t.repeat == 0 -> 2; t.date == LocalDate.now().plusDays(1).toString() -> 1; else -> 0 }
            c.addView(chips(listOf("आज", "कल", "रोज़"), sel) { pickMode(t, it) }, lp(8))

            val expired = t.repeat == 1 && t.on && Alarm.nextMillis(t) < 0 && !Alarm.isDone(this, t.id)
            val state = when {
                t.refs == 0 -> "⚠️ अलार्म चालू करने के लिए कम से कम 1 रेफरेंस फोटो जोड़ें"
                !t.on && Alarm.isDone(this, t.id) -> "✅ आज पूरा (अलार्म बंद है)"
                !t.on -> "⏸ अलार्म बंद है"
                expired -> "⌛ यह समय निकल चुका है। समय आगे करें, या 'कल' / 'रोज़' चुनें"
                Alarm.isDone(this, t.id) -> "✅ आज पूरा"
                else -> "⏳ आज बाकी"
            }
            val nx = Alarm.effectiveNext(this, t)
            c.addView(label(state + (if (nx > 0) "\nअगला अलार्म: ${Alarm.nextText(this, t)}" else ""), 13f, C.MUT), lp(8))

            if (t.refs > 0) {
                val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (i in 0 until t.refs) tr.addView(ImageView(this).apply { setImageBitmap(Store.thumb(this@MainActivity, t, i)); scaleType = ImageView.ScaleType.CENTER_CROP
                    setOnClickListener {
                        android.app.AlertDialog.Builder(this@MainActivity).setMessage("यह रेफरेंस फोटो हटाएं?")
                            .setPositiveButton("हटाएं") { _, _ -> Store.removeRef(this@MainActivity, targets, t, i); saveAll() }
                            .setNegativeButton("रहने दें", null).show() } },
                    LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(0, 0, dp(8), 0) })
                c.addView(tr, lp(8))
                c.addView(label("फोटो हटाने के लिए उस पर टैप करें", 11f, C.MUT), lp(2))
            }

            val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            addBtn(r1, sbtn("📷  फोटो जोड़ें", true) {
                if (t.refs >= Store.MAX_REFS) toast("3 फोटो भरी हैं, पहले कोई हटाएं (फोटो पर टैप करें)")
                else startActivity(Intent(this, CaptureActivity::class.java).putExtra("id", t.id).putExtra("mode", "ref")) })
            addBtn(r1, sbtn("🔍  मैच जांचें", true) {
                if (t.refs == 0) toast("पहले रेफरेंस फोटो जोड़ें")
                else startActivity(Intent(this, CaptureActivity::class.java).putExtra("id", t.id).putExtra("mode", "test")) }, true)
            c.addView(r1, lp(10))
            val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            addBtn(r2, sbtn("✅  अभी कर लिया", true) {
                if (t.refs == 0) toast("पहले रेफरेंस फोटो जोड़ें")
                else startActivity(Intent(this, CaptureActivity::class.java).putExtra("id", t.id).putExtra("mode", "checkin")) })
            addBtn(r2, dbtn("✕  लक्ष्य हटाएं") {
                android.app.AlertDialog.Builder(this).setMessage("यह लक्ष्य और इसकी फोटो हटाएं?")
                    .setPositiveButton("हटाएं") { _, _ -> Store.clearRefs(this, t); Alarm.cancel(this, t); targets.remove(t); Store.save(this, targets); refresh(); status() }
                    .setNegativeButton("रहने दें", null).show() }, true)
            c.addView(r2, lp(4))
            list.addView(c)
        }
    }
}
