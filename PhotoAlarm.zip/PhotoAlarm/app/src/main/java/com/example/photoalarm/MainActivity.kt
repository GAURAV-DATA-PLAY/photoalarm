package com.example.photoalarm

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private var targets = mutableListOf<Target>()
    private lateinit var list: LinearLayout
    private lateinit var st: TextView
    private lateinit var songTxt: TextView
    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) setSong(uri) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = Alarm.prefs(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(20), dp(16), dp(24)); setBackgroundColor(C.BG) }

        val head = card(C.ACC)
        head.addView(label("⏰ जागो", 26f, Color.WHITE, true))
        head.addView(label("हर लक्ष्य का अपना समय, अपनी फोटो", 14f, Color.parseColor("#FFE3D3")))
        root.addView(head)

        val crashF = File(filesDir, "crash.txt")
        if (crashF.exists()) {
            val cc = card(Color.parseColor("#FDE8E8"))
            cc.addView(label("⚠️ पिछली बार ऐप क्रैश हुआ। नीचे लिखे का स्क्रीनशॉट भेजें:", 14f, C.INK, true))
            cc.addView(TextView(this).apply { text = crashF.readText(); textSize = 10f; setTextColor(Color.BLACK); setTextIsSelectable(true) }, lp(6))
            cc.addView(sbtn("ठीक है, हटाएं") { crashF.delete(); cc.visibility = android.view.View.GONE }, lp(6))
            root.addView(cc)
        }

        val tc = card()
        st = label("", 15f, C.MUT)
        tc.addView(st)
        tc.addView(sbtn("🔔 अलार्म टेस्ट करें") { ringTest() }, lp(8))
        root.addView(tc)

        val sc = card()
        sc.addView(label("🎵 अलार्म की आवाज़", 17f, C.INK, true))
        songTxt = label("", 14f, C.MUT); sc.addView(songTxt, lp(4))
        val sr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sr.addView(sbtn("🎶 गाना चुनें") { pick.launch(arrayOf("audio/*")) }, LinearLayout.LayoutParams(0, -2, 1f))
        sr.addView(sbtn("↩ डिफ़ॉल्ट") { File(filesDir, "ringtone").delete(); p.edit().remove("song").apply(); songLabel() }, LinearLayout.LayoutParams(0, -2, 1f))
        sc.addView(sr, lp(6)); root.addView(sc); songLabel()

        val hc = card()
        val thTxt = label("", 14f, C.INK)
        fun thLabel() { thTxt.text = "मैच की सख्ती: ${p.getInt("th", 55)}%  (ज़्यादा = कठिन)" }
        thLabel(); hc.addView(label("🎚 मैच कितना सटीक चाहिए", 17f, C.INK, true)); hc.addView(thTxt, lp(4))
        hc.addView(SeekBar(this).apply { max = 60; progress = p.getInt("th", 55) - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { p.edit().putInt("th", 30 + v).apply(); thLabel() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} }) }, lp(6))
        root.addView(hc)

        val bc = card()
        bc.addView(label("🔋 अलार्म को भरोसेमंद बनाएं", 17f, C.INK, true))
        bc.addView(label("अगर अलार्म समय पर न बजे: बैटरी की छूट दें, और फोन की सेटिंग में इस ऐप के लिए Autostart / Background चालू करें (Realme, Oppo, Vivo, Xiaomi में यह ज़रूरी होता है)।", 13f, C.MUT), lp(4))
        bc.addView(sbtn("🔋 बैटरी की छूट दें") { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }, lp(6))
        bc.addView(sbtn("⚙️ ऐप की सेटिंग खोलें") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }, lp(4))
        root.addView(bc)

        root.addView(label("🎯 मेरे लक्ष्य और अलार्म", 20f, C.INK, true))
        root.addView(label("हर लक्ष्य का अपना समय होता है। उस समय अलार्म बजेगा और उसी जगह की फोटो मैच करने पर बंद होगा। अगर आपने काम पहले ही कर लिया है, तो '✅ अभी कर लिया' से फोटो भेज दें, उस दिन अलार्म नहीं बजेगा।", 13f, C.MUT), lp(4))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, lp(8))
        root.addView(pbtn("➕ नया लक्ष्य जोड़ें") {
            if (targets.size >= 20) return@pbtn
            targets.add(Target(Store.nextId(targets), "", 0, true, 6, 0)); Store.save(this, targets); refresh() }, lp(4))
        setContentView(ScrollView(this).apply { setBackgroundColor(C.BG); addView(root) })

        val need = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(need.toTypedArray(), 1)
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
        else if (!Settings.canDrawOverlays(this) && !p.getBoolean("askedOv", false)) {
            p.edit().putBoolean("askedOv", true).apply()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    override fun onResume() { super.onResume(); targets = Store.load(this); try { Alarm.scheduleAll(this) } catch (e: Throwable) {}; refresh(); status() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun ringTest() {
        val t = targets.firstOrNull { it.refs > 0 } ?: run { toast("पहले किसी लक्ष्य में फोटो जोड़ें"); return }
        Alarm.prefs(this).edit().putBoolean("test", true).apply()
        Alarm.setRinging(this, setOf(t.id))
        startForegroundService(Intent(this, AlarmService::class.java))
    }

    private fun songLabel() { songTxt.text = "वर्तमान: " + (Alarm.prefs(this).getString("song", null) ?: "डिफ़ॉल्ट गाना") }

    private fun setSong(uri: Uri) {
        val tmp = File(filesDir, "ringtone_new")
        try {
            val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else null } ?: "मेरा गाना"
            contentResolver.openInputStream(uri)!!.use { inp -> FileOutputStream(tmp).use { inp.copyTo(it) } }
            val mp = MediaPlayer(); try { mp.setDataSource(tmp.path); mp.prepare() } finally { mp.release() }
            tmp.copyTo(File(filesDir, "ringtone"), overwrite = true); tmp.delete()
            Alarm.prefs(this).edit().putString("song", name).apply(); songLabel()
            toast("✅ गाना लग गया")
        } catch (e: Exception) { tmp.delete(); toast("❌ यह फाइल गाने के रूप में नहीं चली, कोई और चुनें") }
    }

    private fun status() {
        val act = targets.filter { it.on && it.refs > 0 }
        val done = act.count { Alarm.isDone(this, it.id) }
        st.text = "सक्रिय अलार्म: ${act.size}   •   आज पूरे: $done/${act.size}   •   स्ट्रीक: ${Alarm.prefs(this).getInt("streak", 0)} दिन" +
            (Alarm.prefs(this).getString("schedErr", null)?.let { "\n⚠️ अलार्म सेट नहीं हुआ: $it" } ?: "") +
            (Alarm.prefs(this).getString("lastFire", null)?.let { "\nआखिरी बार अलार्म ट्रिगर हुआ: $it" } ?: "") +
            (Alarm.prefs(this).getString("fireErr", null)?.let { "\n⚠️ $it" } ?: "")
    }

    private fun addBtn(row: LinearLayout, txt: String, f: () -> Unit) = row.addView(sbtn(txt, true, f), LinearLayout.LayoutParams(0, -2, 1f))

    private fun saveAll() { Store.save(this, targets); Alarm.scheduleAll(this); refresh(); status() }

    private fun repeatLabel(t: Target) = when (t.repeat) {
        1 -> "सिर्फ एक बार"
        2 -> (0..6).filter { (t.days and (1 shl it)) != 0 }.joinToString(" ") { DAYS_HI[it] }
        else -> "रोज़ (हर दिन अपने आप)"
    }

    private fun repeatDialog(t: Target) {
        android.app.AlertDialog.Builder(this).setTitle("अलार्म कब-कब बजे?")
            .setSingleChoiceItems(arrayOf("रोज़ (हर दिन अपने आप)", "सिर्फ एक बार", "चुने हुए दिन"), t.repeat) { d, which ->
                d.dismiss()
                if (which == 2) daysDialog(t) else { t.repeat = which; saveAll() }
            }.show()
    }

    private fun daysDialog(t: Target) {
        val checked = BooleanArray(7) { (t.days and (1 shl it)) != 0 }
        android.app.AlertDialog.Builder(this).setTitle("कौन से दिन?")
            .setMultiChoiceItems(DAYS_HI, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("ठीक है") { _, _ ->
                var m = 0
                for (i in 0..6) if (checked[i]) m = m or (1 shl i)
                if (m == 0) toast("कम से कम एक दिन चुनें") else { t.repeat = 2; t.days = m; saveAll() }
            }
            .setNegativeButton("रद्द", null).show()
    }

    private fun refresh() {
        list.removeAllViews()
        targets.forEach { t ->
            val c = card()
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            top.addView(EditText(this).apply { hint = "लक्ष्य का नाम (जैसे: ब्रश करो)"; setText(t.name); textSize = 16f
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { t.name = s.toString(); Store.save(this@MainActivity, targets) }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {} }) }, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(Switch(this).apply { isChecked = t.on
                setOnCheckedChangeListener { _, v -> t.on = v; Store.save(this@MainActivity, targets); Alarm.scheduleAll(this@MainActivity); status(); refresh() } })
            c.addView(top)
            c.addView(sbtn("⏰ ${fmtT(t.hour, t.minute)}   (समय बदलें)") {
                android.app.TimePickerDialog(this, { _, h, m -> t.hour = h; t.minute = m; Store.save(this, targets); Alarm.scheduleAll(this)
                    val now = java.util.Calendar.getInstance()
                    if (t.on && t.refs > 0 && !Alarm.isDone(this, t.id) && now.get(java.util.Calendar.HOUR_OF_DAY) == h && now.get(java.util.Calendar.MINUTE) == m) {
                        Alarm.fireSoon(this, t); toast("⏰ यही समय चल रहा है, अलार्म अभी बजेगा") }
                    refresh(); status() }, t.hour, t.minute, false).show() }, lp(6))
            c.addView(sbtn("🔁 दोहराव: ${repeatLabel(t)}   (बदलें)") { repeatDialog(t) }, lp(4))
            val state = when {
                t.refs == 0 -> "⚠️ अलार्म तब चलेगा जब कम से कम 1 रेफरेंस फोटो जोड़ेंगे"
                !t.on && Alarm.isDone(this, t.id) -> "आज: ✅ पूरा (अलार्म बंद है)"
                !t.on -> "⏸ अलार्म बंद है"
                Alarm.isDone(this, t.id) -> "आज: ✅ पूरा, आज अलार्म नहीं बजेगा"
                else -> "आज: ⏳ बाकी"
            }
            c.addView(label(state + (if (t.refs > 0 && t.on) "\nअगला अलार्म: ${Alarm.nextText(this, t)}" else ""), 13f, C.MUT), lp(6))
            if (t.refs > 0 && Alarm.isDone(this, t.id)) {
                c.addView(sbtn("↩ आज फिर से चालू करें (आज भी बजेगा)", true) {
                    Alarm.prefs(this).edit().remove("done_${t.id}").apply()
                    if (!t.on) t.on = true
                    saveAll() }, lp(6))
            }
            if (t.refs > 0) {
                val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (i in 0 until t.refs) tr.addView(ImageView(this).apply { setImageBitmap(Store.thumb(this@MainActivity, t, i)); scaleType = ImageView.ScaleType.CENTER_CROP
                    setOnClickListener {
                        android.app.AlertDialog.Builder(this@MainActivity).setMessage("यह रेफरेंस फोटो हटाएं?")
                            .setPositiveButton("हटाएं") { _, _ -> Store.removeRef(this@MainActivity, targets, t, i); Alarm.scheduleAll(this@MainActivity); refresh(); status() }
                            .setNegativeButton("रहने दें", null).show() } },
                    LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(0, 0, dp(8), 0) })
                c.addView(tr, lp(6))
                c.addView(label("फोटो को हटाने के लिए उस पर टैप करें", 12f, C.MUT), lp(2))
            }
            val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            addBtn(r1, "📷 फोटो जोड़ें") {
                if (t.refs >= Store.MAX_REFS) toast("3 फोटो भरी हैं, पहले कोई हटाएं (फोटो पर टैप करें)")
                else startActivity(Intent(this, CaptureActivity::class.java).putExtra("id", t.id).putExtra("mode", "ref")) }
            addBtn(r1, "🧪 जांच") {
                if (t.refs == 0) toast("पहले रेफरेंस फोटो जोड़ें")
                else startActivity(Intent(this, CaptureActivity::class.java).putExtra("id", t.id).putExtra("mode", "test")) }
            c.addView(r1, lp(6))
            val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            addBtn(r2, "✅ अभी कर लिया") {
                if (t.refs == 0) toast("पहले रेफरेंस फोटो जोड़ें")
                else startActivity(Intent(this, CaptureActivity::class.java).putExtra("id", t.id).putExtra("mode", "checkin")) }
            addBtn(r2, "🗑 लक्ष्य हटाएं") {
                android.app.AlertDialog.Builder(this).setMessage("यह लक्ष्य और इसकी फोटो हटाएं?")
                    .setPositiveButton("हटाएं") { _, _ -> Store.clearRefs(this, t); Alarm.cancel(this, t); targets.remove(t); Store.save(this, targets); refresh(); status() }
                    .setNegativeButton("रहने दें", null).show() }
            c.addView(r2, lp(2))
            list.addView(c)
        }
    }
}
