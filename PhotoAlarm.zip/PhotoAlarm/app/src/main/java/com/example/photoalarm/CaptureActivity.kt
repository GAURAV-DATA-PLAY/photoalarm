package com.example.photoalarm

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.camera.view.PreviewView

class CaptureActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val id = intent.getIntExtra("id", 0)
        val mode = intent.getStringExtra("mode") ?: "ref"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(32), dp(16), dp(16)) }
        val info = TextView(this).apply { textSize = 18f
            text = when (mode) {
                "test" -> "🧪 जांच: उसी जगह की फोटो खींचें और स्कोर देखें"
                "checkin" -> "✅ यह काम कर लिया है? उसी जगह की फोटो खींचें। मैच हुआ तो आज इसका अलार्म नहीं बजेगा"
                else -> "📷 रेफरेंस फोटो: उस जगह की फोटो खींचें जहाँ जाना है"
            } }
        val pv = PreviewView(this)
        val msg = TextView(this).apply { textSize = 16f; gravity = android.view.Gravity.CENTER }
        root.addView(info); root.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(msg)
        val cam = Cam(this, pv) { msg.text = "कैमरे की अनुमति दें" }
        root.addView(Button(this).apply { text = "📸 फोटो खींचें"; setOnClickListener {
            cam.shoot { bmp ->
                try {
                    if (bmp == null) { msg.text = "❌ फोटो नहीं खिंची, फिर कोशिश करें"; return@shoot }
                    val list = Store.load(this@CaptureActivity)
                    val t = list.firstOrNull { it.id == id } ?: run { msg.text = "❌ लक्ष्य नहीं मिला"; return@shoot }
                    if (mode == "ref") { Store.addRef(this@CaptureActivity, list, t, bmp); finish(); return@shoot }
                    val refs = Store.refs(this@CaptureActivity, t)
                    if (refs.isEmpty()) { msg.text = "पहले रेफरेंस फोटो जोड़ें"; return@shoot }
                    val s = Match.score(bmp, refs); val th = Alarm.prefs(this@CaptureActivity).getInt("th", 55) / 100.0
                    val ok = s >= th
                    if (mode == "test") { msg.text = "स्कोर %.2f (चाहिए %.2f) → ".format(s, th) + if (ok) "✅ मैच" else "❌ मैच नहीं"; return@shoot }
                    if (!ok) { msg.text = "❌ मैच नहीं हुआ (%.2f / चाहिए %.2f)। सही जगह की फोटो खींचें।".format(s, th); return@shoot }
                    Store.markDone(this@CaptureActivity, t)
                    val was = id in Alarm.ringing(this@CaptureActivity)
                    Alarm.removeRinging(this@CaptureActivity, id)
                    if (was && Alarm.ringing(this@CaptureActivity).isEmpty()) startService(Intent(this@CaptureActivity, AlarmService::class.java).setAction("STOP"))
                    Toast.makeText(this@CaptureActivity, "✅ आज का यह लक्ष्य पूरा, अलार्म नहीं बजेगा", Toast.LENGTH_LONG).show()
                    finish()
                } catch (e: Throwable) { msg.text = "❌ त्रुटि: ${e.javaClass.simpleName} ${e.message}" }
            } } })
        setContentView(root)
        cam.start()
    }
}
