package com.example.photoalarm

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.camera.view.PreviewView
import java.util.Date

class RingActivity : ComponentActivity() {
    private lateinit var title: TextView
    private lateinit var msg: TextView
    private lateinit var hint: ImageView
    private lateinit var cam: Cam
    private var targets = listOf<Target>()
    private var refs = listOf<Bitmap>()
    private var idx = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() {} })
        targets = Store.load(this).filter { it.refs > 0 && it.on }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(177, 0, 0)); setPadding(dp(16), dp(40), dp(16), dp(16)) }
        title = TextView(this).apply { textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        hint = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val pv = PreviewView(this)
        msg = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER }
        root.addView(title); root.addView(hint, LinearLayout.LayoutParams(-1, dp(110)))
        root.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(msg)
        root.addView(Button(this).apply { text = "📸 फोटो खींचें"; setOnClickListener { shoot() } })
        setContentView(root)
        cam = Cam(this, pv) { msg.text = "कैमरे की अनुमति दें" }
        cam.start()
        show()
    }

    private fun show() {
        if (targets.isEmpty()) { title.text = "उठो! बाहर जाओ और फोटो खींचो\n(ऐप में लक्ष्य जोड़ेंगे तो फोटो मैच होगी)"; hint.visibility = android.view.View.GONE; return }
        val t = targets[idx]
        title.text = "लक्ष्य ${idx + 1}/${targets.size}\n${t.name}"
        refs = Store.refs(this, t)
        if (refs.isNotEmpty()) hint.setImageBitmap(refs[0])
    }

    private fun shoot() {
        cam.shoot { bmp ->
            if (bmp == null) { msg.text = "❌ फोटो नहीं खिंची, फिर कोशिश करें"; return@shoot }
            if (targets.isEmpty()) { done(); return@shoot }
            val s = Match.score(bmp, refs); val th = Alarm.prefs(this).getInt("th", 55) / 100.0
            if (s >= th) {
                idx++
                if (idx >= targets.size) done() else { msg.text = "✅ बढ़िया! अगला लक्ष्य"; show() }
            } else msg.text = "❌ मैच नहीं हुआ (%.2f / चाहिए %.2f)। सही जगह की फोटो खींचें।".format(s, th)
        }
    }

    private fun done() {
        val p = Alarm.prefs(this); val today = Date().toString().substring(0, 10)
        if (p.getString("day", "") != today) p.edit().putInt("streak", p.getInt("streak", 0) + 1).putString("day", today).apply()
        startService(Intent(this, AlarmService::class.java).setAction("STOP"))
        finish()
    }
}
