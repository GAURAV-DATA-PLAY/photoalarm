package com.example.photoalarm

import android.graphics.Bitmap
import android.graphics.Color

object Match {
    fun shrinkMax(b: Bitmap, max: Int): Bitmap {
        var x = b
        while (x.width >= max * 2 || x.height >= max * 2) x = Bitmap.createScaledBitmap(x, x.width / 2, x.height / 2, true)
        return x
    }

    private fun shrink(b: Bitmap, t: Int): Bitmap {
        var x = b
        while (x.width / 2 >= t && x.height / 2 >= t) x = Bitmap.createScaledBitmap(x, x.width / 2, x.height / 2, true)
        return Bitmap.createScaledBitmap(x, t, t, true)
    }

    private fun gray(b: Bitmap, n: Int): DoubleArray {
        val s = shrink(b, n); val g = DoubleArray(n * n)
        for (i in g.indices) { val p = s.getPixel(i % n, i / n); g[i] = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3.0 }
        return g
    }

    private fun hist(b: Bitmap): DoubleArray {
        val s = shrink(b, 32); val h = DoubleArray(64)
        for (i in 0 until 1024) { val p = s.getPixel(i % 32, i / 32)
            h[(Color.red(p) / 64) * 16 + (Color.green(p) / 64) * 4 + Color.blue(p) / 64] += 1.0 }
        for (i in h.indices) h[i] /= 1024.0
        return h
    }

    private fun ncc(a: DoubleArray, b: DoubleArray, n: Int, dx: Int, dy: Int): Double {
        var sa = 0.0; var sb = 0.0; var c = 0
        for (y in 0 until n) { val y2 = y + dy; if (y2 < 0 || y2 >= n) continue
            for (x in 0 until n) { val x2 = x + dx; if (x2 < 0 || x2 >= n) continue
                sa += a[y * n + x]; sb += b[y2 * n + x2]; c++ } }
        if (c == 0) return 0.0
        val ma = sa / c; val mb = sb / c
        var num = 0.0; var da = 0.0; var db = 0.0
        for (y in 0 until n) { val y2 = y + dy; if (y2 < 0 || y2 >= n) continue
            for (x in 0 until n) { val x2 = x + dx; if (x2 < 0 || x2 >= n) continue
                val p = a[y * n + x] - ma; val q = b[y2 * n + x2] - mb
                num += p * q; da += p * p; db += q * q } }
        return if (da < 1e-6 || db < 1e-6) 0.0 else num / Math.sqrt(da * db)
    }

    private fun one(q: Bitmap, r: Bitmap): Double {
        val n = 16; val a = gray(q, n); val b = gray(r, n)
        var best = -1.0
        for (dy in -1..1) for (dx in -1..1) best = maxOf(best, ncc(a, b, n, dx, dy))
        val hq = hist(q); val hr = hist(r)
        var inter = 0.0
        for (i in hq.indices) inter += minOf(hq[i], hr[i])
        return 0.6 * maxOf(0.0, best) + 0.4 * inter
    }

    /** 0.0 से 1.0 तक। जितना ज़्यादा, उतनी मिलती-जुलती फोटो। */
    fun score(q: Bitmap, refs: List<Bitmap>): Double = refs.maxOfOrNull { one(q, it) } ?: 0.0
}
