package com.example.photoalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.util.Calendar

object Alarm {
    fun prefs(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun today() = LocalDate.now().toString()
    fun isDone(c: Context, id: Int) = prefs(c).getString("done_$id", "") == today()

    fun ringing(c: Context): Set<Int> = prefs(c).getString("ringing", "")!!.split(",").mapNotNull { it.toIntOrNull() }.toSet()
    fun setRinging(c: Context, s: Set<Int>) { prefs(c).edit().putString("ringing", s.joinToString(",")).apply() }
    fun addRinging(c: Context, id: Int) = setRinging(c, ringing(c) + id)
    fun removeRinging(c: Context, id: Int) = setRinging(c, ringing(c) - id)

    private fun pi(c: Context, t: Target, flags: Int): PendingIntent? =
        PendingIntent.getBroadcast(c, 1000 + t.id, Intent(c, AlarmReceiver::class.java).putExtra("tid", t.id), flags)

    fun nextMillis(t: Target): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, t.hour); set(Calendar.MINUTE, t.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis() + 1000) add(Calendar.DAY_OF_YEAR, 1)
    }.timeInMillis

    /** "आज 3:10 PM (0 घंटे 2 मिनट में)" जैसा लिखा हुआ अगला अलार्म। */
    fun nextText(c: Context, t: Target): String {
        var ms = nextMillis(t)
        val now = Calendar.getInstance(); val nc = Calendar.getInstance().apply { timeInMillis = ms }
        var today = nc.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR) && nc.get(Calendar.YEAR) == now.get(Calendar.YEAR)
        if (today && isDone(c, t.id)) { ms += 86400000L; today = false }
        val mins = (ms - System.currentTimeMillis()) / 60000
        return (if (today) "आज " else "कल ") + fmtT(t.hour, t.minute) + " (${mins / 60} घंटे ${mins % 60} मिनट में)"
    }

    private fun set(c: Context, t: Target, at: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, t, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)!!)
    }

    fun schedule(c: Context, t: Target) = set(c, t, nextMillis(t))

    /** चुना हुआ समय अभी का ही मिनट हो तो 2 सेकंड बाद बजा दो। */
    fun fireSoon(c: Context, t: Target) = set(c, t, System.currentTimeMillis() + 2000)

    fun cancel(c: Context, t: Target) {
        val p = pi(c, t, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(p)
    }

    fun scheduleAll(c: Context) {
        prefs(c).edit().remove("schedErr").apply()
        Store.load(c).forEach {
            try { if (it.on && it.refs > 0) schedule(c, it) else cancel(c, it) }
            catch (e: Exception) { prefs(c).edit().putString("schedErr", e.toString()).apply() }
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("tid", -1)
        val t = Store.load(c).firstOrNull { it.id == id } ?: return
        val p = Alarm.prefs(c)
        val stamp = java.text.SimpleDateFormat("d MMM, h:mm:ss a", java.util.Locale.getDefault()).format(java.util.Date())
        p.edit().putBoolean("test", false).putString("lastFire", "$stamp (${t.name})").apply()
        if (t.on && t.refs > 0) Alarm.schedule(c, t) // कल के लिए फिर लगाओ
        if (!t.on || t.refs <= 0 || Alarm.isDone(c, id)) { p.edit().putString("fireErr", "आज यह लक्ष्य पहले ही पूरा था, इसलिए नहीं बजा").apply(); return }
        Alarm.setRinging(c, Alarm.ringing(c).filter { !Alarm.isDone(c, it) }.toSet())
        Alarm.addRinging(c, id)
        try { c.startForegroundService(Intent(c, AlarmService::class.java)); p.edit().remove("fireErr").apply() }
        catch (e: Exception) { p.edit().putString("fireErr", e.toString()).apply() }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Alarm.scheduleAll(c) }
}
