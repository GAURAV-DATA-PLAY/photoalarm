package com.example.photoalarm

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

data class Target(val id: Int, var name: String, var refs: Int, var on: Boolean = true)

object Store {
    const val MAX_REFS = 3

    fun load(c: Context): MutableList<Target> {
        val out = mutableListOf<Target>()
        val a = JSONArray(Alarm.prefs(c).getString("targets", "[]"))
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); out.add(Target(o.getInt("id"), o.getString("name"), o.getInt("refs"), o.optBoolean("on", true))) }
        return out
    }

    fun save(c: Context, l: List<Target>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("refs", it.refs).put("on", it.on)) }
        Alarm.prefs(c).edit().putString("targets", a.toString()).apply()
    }

    fun nextId(l: List<Target>) = (l.maxOfOrNull { it.id } ?: 0) + 1
    fun file(c: Context, id: Int, i: Int) = File(c.filesDir, "ref_${id}_$i.jpg")

    fun refs(c: Context, t: Target): List<Bitmap> =
        (0 until t.refs).mapNotNull { BitmapFactory.decodeFile(file(c, t.id, it).path) }

    fun clearRefs(c: Context, t: Target) {
        for (i in 0 until MAX_REFS) file(c, t.id, i).delete()
        t.refs = 0
    }

    fun addRef(c: Context, list: List<Target>, t: Target, bmp: Bitmap) {
        if (t.refs >= MAX_REFS) clearRefs(c, t)
        val small = Match.shrinkMax(bmp, 512)
        FileOutputStream(file(c, t.id, t.refs)).use { small.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        t.refs++
        save(c, list)
    }
}
