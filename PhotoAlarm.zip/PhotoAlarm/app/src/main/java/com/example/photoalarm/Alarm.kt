package com.example.photoalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Alarm {
    fun prefs(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)

    fun schedule(c: Context) {
        val p = prefs(c)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, p.getInt("h", 4)); set(Calendar.MINUTE, p.getInt("m", 0))
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 1000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val fire = PendingIntent.getBroadcast(c, 1, Intent(c, AlarmReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val show = PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, show), fire)
        p.edit().putBoolean("on", true).apply()
    }
}

class AlarmReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Alarm.schedule(c) // कल के लिए फिर लगाओ
        c.startForegroundService(Intent(c, AlarmService::class.java))
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Alarm.prefs(c).getBoolean("on", false)) Alarm.schedule(c)
    }
}
