package com.example.photoalarm

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

class Cam(private val a: ComponentActivity, private val pv: PreviewView, private val onDenied: () -> Unit) {
    private var cap: ImageCapture? = null
    private val req = a.registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) bind() else onDenied() }

    fun start() {
        if (a.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) bind() else req.launch(Manifest.permission.CAMERA)
    }

    private fun bind() {
        val f = ProcessCameraProvider.getInstance(a)
        f.addListener({
            val prov = f.get()
            val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            val ic = ImageCapture.Builder().build()
            cap = ic
            prov.unbindAll()
            prov.bindToLifecycle(a, CameraSelector.DEFAULT_BACK_CAMERA, prev, ic)
        }, ContextCompat.getMainExecutor(a))
    }

    fun shoot(cb: (Bitmap?) -> Unit) {
        val c = cap ?: run { cb(null); return }
        c.takePicture(ContextCompat.getMainExecutor(a), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                var out: Bitmap? = null
                try {
                    val deg = image.imageInfo.rotationDegrees
                    val buf = image.planes[0].buffer
                    val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var s = 1
                    while (maxOf(o.outWidth, o.outHeight) / s > 1400) s *= 2
                    var b = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                    if (b != null && deg != 0) { val m = Matrix(); m.postRotate(deg.toFloat()); b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true) }
                    out = b
                } catch (e: Throwable) { out = null } finally { image.close() }
                cb(out)
            }
            override fun onError(e: ImageCaptureException) { cb(null) }
        })
    }
}
