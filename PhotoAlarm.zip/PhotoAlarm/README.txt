APK बनाने के तरीके

(A) बिना कंप्यूटर: github.com पर फ्री अकाउंट बनाएं -> New repository -> इस ज़िप की सारी फाइलें (फोल्डर समेत, .github भी) Upload करें
    -> Actions टैब -> "Build APK" -> Run workflow -> खत्म होने पर नीचे Artifacts से PhotoAlarm-APK डाउनलोड करें -> ज़िप खोलकर app-debug.apk इंस्टॉल करें।
(B) कंप्यूटर पर: Android Studio में यह फोल्डर Open करें -> Build > Build APK(s)।

इंस्टॉल के बाद: कैमरा/नोटिफिकेशन अनुमति दें, "Full screen intent" अनुमति दें, और
Settings > Apps > फोटो अलार्म > Battery > Unrestricted करें। पहले "अभी टेस्ट करें" से जांचें।
