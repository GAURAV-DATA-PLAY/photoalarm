package com.example.photoalarm

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun fmtT(h: Int, m: Int) = "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "AM" else "PM")

data class Target(val id: Int, var name: String, var refs: Int, var on: Boolean = true, var hour: Int = 6, var minute: Int = 0, var repeat: Int = 0, var days: Int = 127)

object Store {
    const val MAX_REFS = 3

    fun load(c: Context): MutableList<Target> {
        val out = mutableListOf<Target>()
        val a = JSONArray(Alarm.prefs(c).getString("targets", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Target(o.getInt("id"), o.getString("name"), o.getInt("refs"), o.optBoolean("on", true), o.optInt("hour", 6), o.optInt("minute", 0), o.optInt("repeat", 0), o.optInt("days", 127)))
        }
        return out
    }

    fun save(c: Context, l: List<Target>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("refs", it.refs).put("on", it.on).put("hour", it.hour).put("minute", it.minute).put("repeat", it.repeat).put("days", it.days)) }
        Alarm.prefs(c).edit().putString("targets", a.toString()).apply()
    }

    fun nextId(l: List<Target>) = (l.maxOfOrNull { it.id } ?: 0) + 1
    fun file(c: Context, id: Int, i: Int) = File(c.filesDir, "ref_${id}_$i.jpg")

    fun refs(c: Context, t: Target): List<Bitmap> =
        (0 until t.refs).mapNotNull { BitmapFactory.decodeFile(file(c, t.id, it).path) }

    fun thumb(c: Context, t: Target, i: Int): Bitmap? =
        BitmapFactory.decodeFile(file(c, t.id, i).path, BitmapFactory.Options().apply { inSampleSize = 4 })

    fun clearRefs(c: Context, t: Target) {
        for (i in 0 until MAX_REFS) file(c, t.id, i).delete()
        t.refs = 0
    }

    fun removeRef(c: Context, list: List<Target>, t: Target, i: Int) {
        file(c, t.id, i).delete()
        for (j in i + 1 until t.refs) file(c, t.id, j).renameTo(file(c, t.id, j - 1))
        t.refs = maxOf(0, t.refs - 1)
        save(c, list)
    }

    fun addRef(c: Context, list: List<Target>, t: Target, bmp: Bitmap) {
        if (t.refs >= MAX_REFS) return
        val small = Match.shrinkMax(bmp, 512)
        FileOutputStream(file(c, t.id, t.refs)).use { small.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        t.refs++
        save(c, list)
    }

    /** आज के लिए यह लक्ष्य पूरा। सब पूरे हों तो स्ट्रीक बढ़ती है। */
    fun markDone(c: Context, t: Target) {
        val p = Alarm.prefs(c)
        p.edit().putString("done_${t.id}", Alarm.today()).apply()
        val active = load(c).filter { (it.on || it.id == t.id) && it.refs > 0 }
        if (active.all { Alarm.isDone(c, it.id) } && p.getString("day", "") != Alarm.today()) {
            val yesterday = LocalDate.now().minusDays(1).toString()
            val s = if (p.getString("day", "") == yesterday) p.getInt("streak", 0) + 1 else 1
            p.edit().putInt("streak", s).putString("day", Alarm.today()).apply()
        }
        // "सिर्फ एक बार" वाला लक्ष्य पूरा होते ही अपने आप बंद हो जाता है
        if (t.repeat == 1) {
            val l = load(c); l.firstOrNull { it.id == t.id }?.on = false; save(c, l); Alarm.cancel(c, t)
        }
    }
}
