package com.example.photoalarm

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.camera.view.PreviewView

class RingActivity : ComponentActivity() {
    private lateinit var title: TextView
    private lateinit var msg: TextView
    private lateinit var hint: ImageView
    private lateinit var cam: Cam
    private var queue = listOf<Target>()
    private var refs = listOf<Bitmap>()
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { sync(); h.postDelayed(this, 2000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() {} })
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(177, 0, 0)); setPadding(dp(16), dp(40), dp(16), dp(16)) }
        title = TextView(this).apply { textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        hint = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val pv = PreviewView(this)
        msg = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER }
        root.addView(title); root.addView(hint, LinearLayout.LayoutParams(-1, dp(110)))
        root.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f)); root.addView(msg)
        root.addView(Button(this).apply { text = "🔄 कैमरा बदलें (आगे / पीछे)"; setOnClickListener { cam.flip() } })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text = "🔄 कैमरा बदलें"; setOnClickListener { cam.flip() } }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply { text = "📸 फोटो खींचें"; setOnClickListener { shoot() } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        setContentView(root)
        cam = Cam(this, pv) { msg.text = "कैमरे की अनुमति दें" }
        cam.start(false)
        h.post(tick)
    }

    override fun onResume() { super.onResume(); quiet() }
    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }

    private fun quiet() { startService(Intent(this, AlarmService::class.java).setAction("QUIET")) }

    private fun sync() {
        val ids = Alarm.ringing(this)
        val q = Store.load(this).filter { it.id in ids && it.refs > 0 }
        if (q.isEmpty()) { startService(Intent(this, AlarmService::class.java).setAction("STOP")); finish(); return }
        if (q.map { it.id } != queue.map { it.id }) { queue = q; show(); quiet() }
    }

    private fun show() {
        val t = queue[0]
        cam.setFront(t.cam == 1)
        refs = Store.refs(this, t)
        title.text = "⏰ ${t.name.ifBlank { "लक्ष्य" }}\n${fmtT(t.hour, t.minute)}" + if (queue.size > 1) "\n(और ${queue.size - 1} लक्ष्य बाकी)" else ""
        hint.setImageBitmap(refs.firstOrNull()); hint.visibility = View.VISIBLE
    }

    private fun shoot() {
        cam.shoot { bmp ->
            if (bmp == null) { msg.text = "❌ फोटो नहीं खिंची, फिर कोशिश करें"; return@shoot }
            if (queue.isEmpty()) return@shoot
            val t = queue[0]
            val s = Match.score(bmp, refs); val th = Alarm.prefs(this).getInt("th", 55) / 100.0
            if (s >= th) {
                if (!Alarm.prefs(this).getBoolean("test", false)) Store.markDone(this, t)
                Alarm.removeRinging(this, t.id)
                msg.text = "✅ बढ़िया!"
                sync()
            } else msg.text = "❌ मैच नहीं हुआ (%.2f / चाहिए %.2f)। सही जगह की फोटो खींचें।".format(s, th)
        }
    }
}
