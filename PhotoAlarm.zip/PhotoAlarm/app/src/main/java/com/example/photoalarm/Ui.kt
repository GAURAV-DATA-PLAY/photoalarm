package com.example.photoalarm

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.*

object C {
    val BG = Color.parseColor("#F6F5F1"); val ACC = Color.parseColor("#D9480F")
    val INK = Color.parseColor("#1C1B19"); val MUT = Color.parseColor("#6B675F")
}

fun Context.shape(color: Int, r: Int = 16, stroke: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
}

fun Context.lp(top: Int = 8) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, 0) }

fun Context.card(bg: Int = Color.WHITE) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; background = shape(bg); setPadding(dp(16), dp(14), dp(16), dp(14))
    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) }
}

fun Context.label(t: String, size: Float = 14f, color: Int = C.INK, bold: Boolean = false) = TextView(this).apply {
    text = t; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.pbtn(t: String, f: () -> Unit) = Button(this).apply {
    text = t; isAllCaps = false; textSize = 16f; setTextColor(Color.WHITE); background = shape(C.ACC, 12); setOnClickListener { f() }
}

fun Context.sbtn(t: String, small: Boolean = false, f: () -> Unit) = Button(this).apply {
    text = t; isAllCaps = false; textSize = if (small) 13f else 15f; setTextColor(C.ACC)
    background = shape(Color.TRANSPARENT, 12, C.ACC); setOnClickListener { f() }
}

fun Context.dbtn(t: String, f: () -> Unit) = Button(this).apply {
    text = t; isAllCaps = false; textSize = 13f; setTextColor(Color.parseColor("#C92A2A"))
    background = shape(Color.TRANSPARENT, 12, Color.parseColor("#C92A2A")); setOnClickListener { f() }
}

fun Context.chips(labels: List<String>, sel: Int, f: (Int) -> Unit) = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL; background = shape(Color.parseColor("#EFEDE8"), 12); setPadding(dp(3), dp(3), dp(3), dp(3))
    labels.forEachIndexed { i, l ->
        addView(TextView(this@chips).apply {
            text = l; gravity = android.view.Gravity.CENTER; textSize = 14f; setPadding(0, dp(10), 0, dp(10))
            if (i == sel) { setTextColor(Color.WHITE); background = shape(C.ACC, 10); setTypeface(typeface, Typeface.BOLD) } else setTextColor(C.INK)
            setOnClickListener { f(i) } }, LinearLayout.LayoutParams(0, -2, 1f))
    }
}

fun Context.stat(num: String, lbl: String) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; gravity = android.view.Gravity.CENTER; background = shape(Color.WHITE, 16); setPadding(dp(8), dp(14), dp(8), dp(14))
    addView(label(num, 24f, C.ACC, true).apply { gravity = android.view.Gravity.CENTER })
    addView(label(lbl, 12f, C.MUT).apply { gravity = android.view.Gravity.CENTER })
}
