package com.example.photoalarm

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.*

class AlarmService : Service() {
    private var mp: MediaPlayer? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("alarm", "अलार्म", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
        val pi = PendingIntent.getActivity(this, 3, Intent(this, RingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "alarm").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("उठो! बाहर जाओ और फोटो खींचो").setContentText("फोटो खींचने तक अलार्म नहीं रुकेगा")
            .setCategory(Notification.CATEGORY_ALARM).setOngoing(true).setContentIntent(pi).setFullScreenIntent(pi, true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(1, n)

        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "photoalarm:ring").apply { acquire(2 * 60 * 60 * 1000L) }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        if (mp == null) {
            mp = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                val custom = java.io.File(filesDir, "ringtone")
                try { if (custom.exists()) setDataSource(custom.path) else throw Exception("no custom") }
                catch (e: Exception) { reset(); resources.openRawResourceFd(R.raw.alarm).use { setDataSource(it.fileDescriptor, it.startOffset, it.length) } }
                isLooping = true; prepare(); start()
            }
        }
        val vib = getSystemService(Vibrator::class.java)
        vib.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 400), 0))
        try { startActivity(Intent(this, RingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
        return START_STICKY
    }

    override fun onDestroy() {
        mp?.release(); mp = null
        getSystemService(Vibrator::class.java).cancel()
        try { wl?.release() } catch (e: Exception) {}
        super.onDestroy()
    }
}
