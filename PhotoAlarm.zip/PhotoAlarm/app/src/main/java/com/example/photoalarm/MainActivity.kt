package com.example.photoalarm

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream

class MainActivity : ComponentActivity() {
    private var targets = mutableListOf<Target>()
    private lateinit var list: LinearLayout
    private lateinit var st: TextView
    private lateinit var songTxt: TextView
    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) setSong(uri) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = Alarm.prefs(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(20), dp(16), dp(24)); setBackgroundColor(C.BG) }

        val head = card(C.ACC)
        head.addView(label("⏰ जागो", 26f, Color.WHITE, true))
        head.addView(label("फोटो मैच किए बिना अलार्म नहीं रुकेगा", 14f, Color.parseColor("#FFE3D3")))
        root.addView(head)

        val tc = card()
        val tp = TimePicker(this).apply { setIs24HourView(false); hour = p.getInt("h", 4); minute = p.getInt("m", 0) }
        st = label("", 15f, C.MUT)
        tc.addView(tp)
        tc.addView(pbtn("अलार्म चालू करें") { p.edit().putInt("h", tp.hour).putInt("m", tp.minute).apply(); Alarm.schedule(this); status() }, lp(8))
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r.addView(sbtn("अभी टेस्ट करें") { startForegroundService(Intent(this, AlarmService::class.java)) }, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(sbtn("अलार्म बंद करें") {
            p.edit().putBoolean("on", false).apply()
            val pi = PendingIntent.getBroadcast(this, 1, Intent(this, AlarmReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pi != null) (getSystemService(ALARM_SERVICE) as AlarmManager).cancel(pi)
            status() }, LinearLayout.LayoutParams(0, -2, 1f))
        tc.addView(r, lp(4)); tc.addView(st, lp(8)); root.addView(tc)

        val sc = card()
        sc.addView(label("🎵 अलार्म की आवाज़", 17f, C.INK, true))
        songTxt = label("", 14f, C.MUT); sc.addView(songTxt, lp(4))
        val sr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sr.addView(sbtn("🎶 गाना चुनें") { pick.launch(arrayOf("audio/*")) }, LinearLayout.LayoutParams(0, -2, 1f))
        sr.addView(sbtn("↩ डिफ़ॉल्ट") { File(filesDir, "ringtone").delete(); p.edit().remove("song").apply(); songLabel() }, LinearLayout.LayoutParams(0, -2, 1f))
        sc.addView(sr, lp(6)); root.addView(sc); songLabel()

        val hc = card()
        val thTxt = label("", 14f, C.INK)
        fun thLabel() { thTxt.text = "मैच की सख्ती: ${p.getInt("th", 55)}%  (ज़्यादा = कठिन)" }
        thLabel(); hc.addView(label("🎚 मैच कितना सटीक चाहिए", 17f, C.INK, true)); hc.addView(thTxt, lp(4))
        hc.addView(SeekBar(this).apply { max = 60; progress = p.getInt("th", 55) - 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { p.edit().putInt("th", 30 + v).apply(); thLabel() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {} }) }, lp(6))
        root.addView(hc)

        root.addView(label("🎯 सुबह के लक्ष्य", 20f, C.INK, true))
        root.addView(label("एक बार फोटो जोड़ दें, वह हर दिन अपने आप इस्तेमाल होगी। लक्ष्य ऊपर से नीचे क्रम में पूरे करने होंगे। 'चालू' बंद करने पर वह लक्ष्य आज के लिए छूट जाएगा।", 13f, C.MUT), lp(4))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, lp(8))
        root.addView(pbtn("➕ नया लक्ष्य जोड़ें") {
            if (targets.size >= 20) return@pbtn
            targets.add(Target(Store.nextId(targets), "", 0)); Store.save(this, targets); refresh() }, lp(4))
        setContentView(ScrollView(this).apply { setBackgroundColor(C.BG); addView(root) })

        val need = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(need.toTypedArray(), 1)
        if (Build.VERSION.SDK_INT >= 34 && !getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
    }

    override fun onResume() { super.onResume(); targets = Store.load(this); refresh(); status() }

    private fun fmt(h: Int, m: Int) = "%d:%02d %s".format(if (h % 12 == 0) 12 else h % 12, m, if (h < 12) "AM" else "PM")

    private fun songLabel() { songTxt.text = "वर्तमान: " + (Alarm.prefs(this).getString("song", null) ?: "डिफ़ॉल्ट गाना") }

    private fun setSong(uri: Uri) {
        val tmp = File(filesDir, "ringtone_new")
        try {
            val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (c.moveToFirst() && i >= 0) c.getString(i) else null } ?: "मेरा गाना"
            contentResolver.openInputStream(uri)!!.use { inp -> FileOutputStream(tmp).use { inp.copyTo(it) } }
            val mp = MediaPlayer(); try { mp.setDataSource(tmp.path); mp.prepare() } finally { mp.release() }
            tmp.copyTo(File(filesDir, "ringtone"), overwrite = true); tmp.delete()
            Alarm.prefs(this).edit().putString("song", name).apply(); songLabel()
            Toast.makeText(this, "✅ गाना लग गया", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            tmp.delete(); Toast.makeText(this, "❌ यह फाइल गाने के रूप में नहीं चली, कोई और चुनें", Toast.LENGTH_LONG).show()
        }
    }

    private fun status() {
        val p = Alarm.prefs(this)
        val ready = targets.count { it.refs > 0 && it.on }
        st.text = (if (p.getBoolean("on", false)) "अलार्म चालू ✅ ${fmt(p.getInt("h", 4), p.getInt("m", 0))}" else "अलार्म बंद") +
            "   •   लक्ष्य तैयार: $ready/${targets.size}   •   स्ट्रीक: ${p.getInt("streak", 0)} दिन"
    }

    private fun refresh() {
        list.removeAllViews()
        targets.forEachIndexed { i, t ->
            val c = card()
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
            top.addView(EditText(this).apply { hint = "लक्ष्य ${i + 1} (जैसे: ब्रश करो)"; setText(t.name); textSize = 16f
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { t.name = s.toString(); Store.save(this@MainActivity, targets) }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {} }) }, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(Switch(this).apply { isChecked = t.on
                setOnCheckedChangeListener { _, v -> t.on = v; Store.save(this@MainActivity, targets); status() } })
            c.addView(top)
            c.addView(label(if (t.refs > 0) "✅ रेफरेंस फोटो: ${t.refs}/${Store.MAX_REFS} (सेव है, हर दिन चलेगी)" else "⚠️ अभी कोई रेफरेंस फोटो नहीं", 13f, C.MUT), lp(2))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun add(txt: String, f: () -> Unit) = row.addView(sbtn(txt, true, f), LinearLayout.LayoutParams(0, -2, 1f))
            add("⬆") { if (i > 0) { java.util.Collections.swap(targets, i, i - 1); Store.save(this, targets); refresh() } }
            add(if (t.refs >= Store.MAX_REFS) "📷 बदलें" else "📷 फोटो") { startActivity(Intent(this, CaptureActivity::class.java).putExtra("id", t.id)) }
            add("🧪 जांच") { startActivity(Intent(this, CaptureActivity::class.java).putExtra("id", t.id).putExtra("test", true)) }
            add("🗑") { Store.clearRefs(this, t); targets.remove(t); Store.save(this, targets); refresh(); status() }
            c.addView(row, lp(6))
            list.addView(c)
        }
    }
}
