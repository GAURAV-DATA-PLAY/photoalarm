package com.example.photoalarm

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.Date

class RingActivity : ComponentActivity() {
    private var capture: ImageCapture? = null
    private lateinit var msg: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() {} })
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(177, 0, 0)); setPadding(32, 64, 32, 32) }
        root.addView(TextView(this).apply { text = "उठो! 🌅\nबाहर जाओ और अभी फोटो खींचो"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        val pv = PreviewView(this); root.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f))
        msg = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER }; root.addView(msg)
        root.addView(Button(this).apply { text = "📷 फोटो खींचें और अलार्म बंद करें"; setOnClickListener { shoot() } })
        setContentView(root)
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCam(pv)
        else registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { if (it) startCam(pv) else msg.text = "कैमरे की अनुमति दें" }.launch(Manifest.permission.CAMERA)
    }

    private fun startCam(pv: PreviewView) {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val prov = f.get()
            val prev = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            capture = ImageCapture.Builder().build()
            prov.unbindAll()
            prov.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, prev, capture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun shoot() {
        val c = capture ?: run { msg.text = "कैमरा तैयार नहीं"; return }
        c.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp = image.toBitmap(); image.close()
                if (!ok(bmp)) { msg.text = "❌ फोटो बहुत अंधेरी/खाली है। रोशनी वाली जगह जाएं।"; return }
                done()
            }
            override fun onError(e: ImageCaptureException) { msg.text = "❌ फोटो नहीं खिंची, फिर कोशिश करें" }
        })
    }

    private fun ok(src: Bitmap): Boolean {
        val s = Bitmap.createScaledBitmap(src, 32, 32, true); val g = IntArray(1024)
        for (i in 0 until 1024) { val p = s.getPixel(i % 32, i / 32); g[i] = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3 }
        val mean = g.average(); return g.sumOf { (it - mean) * (it - mean) } / 1024 >= 5
    }

    private fun done() {
        val p = Alarm.prefs(this); val today = Date().toString().substring(0, 10)
        if (p.getString("day", "") != today) p.edit().putInt("streak", p.getInt("streak", 0) + 1).putString("day", today).apply()
        startService(Intent(this, AlarmService::class.java).setAction("STOP"))
        finish()
    }
}
