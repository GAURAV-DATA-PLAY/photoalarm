package com.example.photoalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.util.Calendar

object Alarm {
    fun prefs(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    fun today() = LocalDate.now().toString()
    fun isDone(c: Context, id: Int) = prefs(c).getString("done_$id", "") == today()

    fun ringing(c: Context): Set<Int> = prefs(c).getString("ringing", "")!!.split(",").mapNotNull { it.toIntOrNull() }.toSet()
    fun setRinging(c: Context, s: Set<Int>) { prefs(c).edit().putString("ringing", s.joinToString(",")).apply() }
    fun addRinging(c: Context, id: Int) = setRinging(c, ringing(c) + id)
    fun removeRinging(c: Context, id: Int) = setRinging(c, ringing(c) - id)

    private fun pi(c: Context, t: Target, flags: Int): PendingIntent? =
        PendingIntent.getBroadcast(c, 1000 + t.id, Intent(c, AlarmReceiver::class.java).putExtra("tid", t.id), flags)

    fun schedule(c: Context, t: Target) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, t.hour); set(Calendar.MINUTE, t.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 1000) add(Calendar.DAY_OF_YEAR, 1)
        }
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, show), pi(c, t, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)!!)
    }

    fun cancel(c: Context, t: Target) {
        val p = pi(c, t, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(p)
    }

    fun scheduleAll(c: Context) {
        Store.load(c).forEach { if (it.on && it.refs > 0) schedule(c, it) else cancel(c, it) }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("tid", -1)
        val t = Store.load(c).firstOrNull { it.id == id } ?: return
        Alarm.prefs(c).edit().putBoolean("test", false).apply()
        if (t.on && t.refs > 0) Alarm.schedule(c, t) // कल के लिए फिर लगाओ
        if (!t.on || t.refs <= 0 || Alarm.isDone(c, id)) return // आज पहले ही पूरा है तो अलार्म नहीं
        Alarm.setRinging(c, Alarm.ringing(c).filter { !Alarm.isDone(c, it) }.toSet())
        Alarm.addRinging(c, id)
        c.startForegroundService(Intent(c, AlarmService::class.java))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Alarm.scheduleAll(c) }
}
